---
title: Requirements
weight: 10
disableToc: true
---

Thanks to the simplicity of Hugo, this page is as empty as this theme needs requirements.

Just download latest version of [Hugo binary (> 0.25)](https://gohugo.io/getting-started/installing/) for your OS (Windows, Linux, Mac) : it's that simple.

![Magic](/en/basics/requirements/images/magic.gif?classes=shadow)
